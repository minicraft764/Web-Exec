(() => {
  // Prevent duplicate notifications
  const existingNotification = document.getElementById('custom-inject-toast');
  if (existingNotification) existingNotification.remove();

  // Create elements
  const toast = document.createElement('div');
  toast.id = 'custom-inject-toast';

  const textNode = document.createTextNode('command injected successfully');
  
  const closeBtn = document.createElement('span');
  closeBtn.innerHTML = '&times;';

  const progressBar = document.createElement('div');

  // Inline Styles
  Object.assign(toast.style, {
    position: 'fixed',
    bottom: '20px',
    right: '20px',
    transform: 'translateX(calc(100% + 30px))',
    backgroundColor: '#1e1e2d',
    color: '#ffffff',
    padding: '14px 20px 18px 20px',
    borderRadius: '8px',
    boxShadow: '0 10px 25px rgba(0,0,0,0.3)',
    fontFamily: 'system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
    fontSize: '14px',
    fontWeight: '500',
    zIndex: '2147483647',
    display: 'flex',
    alignItems: 'center',
    gap: '15px',
    direction: 'ltr',
    textAlign: 'left',
    boxSizing: 'border-box',
    overflow: 'hidden',
    transition: 'transform 0.8s cubic-bezier(0.16, 1, 0.3, 1)'
  });

  Object.assign(closeBtn.style, {
    cursor: 'pointer',
    fontSize: '18px',
    lineHeight: '1',
    color: '#a1a5b7',
    transition: 'color 0.2s ease',
    userSelect: 'none'
  });

  Object.assign(progressBar.style, {
    position: 'absolute',
    bottom: '0',
    left: '0',
    height: '3px',
    width: '100%',
    backgroundColor: '#3b82f6',
    transition: 'width 2s linear'
  });

  // Assemble elements
  toast.appendChild(textNode);
  toast.appendChild(closeBtn);
  toast.appendChild(progressBar);
  document.body.appendChild(toast);

  // Animate Entry
  requestAnimationFrame(() => {
    toast.style.transform = 'translateX(0)';
    progressBar.style.width = '0%';
  });

  // Dismiss function
  let isClosing = false;
  const closeToast = () => {
    if (isClosing) return;
    isClosing = true;
    toast.style.transform = 'translateX(calc(100% + 30px))';
    setTimeout(() => toast.remove(), 800);
  };

  // Event Listeners & Auto-close timer
  closeBtn.addEventListener('mouseenter', () => closeBtn.style.color = '#ffffff');
  closeBtn.addEventListener('mouseleave', () => closeBtn.style.color = '#a1a5b7');
  closeBtn.addEventListener('click', closeToast);

  setTimeout(closeToast, 2000);
})();