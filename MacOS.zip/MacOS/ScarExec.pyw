import sys
import os
import json
import threading
import time
import getpass
import urllib.request
import re
from pathlib import Path
from datetime import datetime

from flask import Flask, jsonify, request

from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QFileDialog, QLabel, QCheckBox, QScrollArea,
    QSplitter, QTabWidget, QInputDialog, QListWidget, QListWidgetItem,
    QTabBar, QStylePainter, QStyleOptionTab, QStyle, QSlider, QGroupBox,
    QStackedWidget, QDialog, QTextEdit, QGridLayout, QGraphicsOpacityEffect,
    QLineEdit, QFrame, QMenu, QMessageBox, QShortcut
)
from PyQt5.QtGui import QColor, QPainter, QKeySequence, QDesktopServices, QIcon, QFontDatabase, QFont
from PyQt5.QtCore import Qt, pyqtSignal, QObject, QTimer, QUrl, QSize, QPropertyAnimation, QEasingCurve
from PyQt5.QtWebEngineWidgets import QWebEngineView, QWebEngineSettings


# ============================================================================
# CONFIGURATION & PATHS
# ============================================================================
def resource_path(relative_path):
    try:
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base_path, relative_path)

if getattr(sys, 'frozen', False):
    BASE_DIR = os.path.dirname(sys.executable)
else:
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))

SCRIPTS_FOLDER = os.path.join(BASE_DIR, "load folder")
SESSION_FILE = os.path.join(BASE_DIR, "session_data.json")
SETTINGS_FILE = os.path.join(BASE_DIR, "settings.json")

os.makedirs(SCRIPTS_FOLDER, exist_ok=True)

SHOP_DATA_URL = "https://raw.githubusercontent.com/minicraft764/store/refs/heads/main/scripts.json"

# ============================================================================
# EMBEDDED EXTENSION SOURCE FILES (MULTI-TIER NON-DEBUGGER INJECTION)
# ============================================================================
EXTENSION_BACKGROUND_JS = """const SERVER_URL = "http://127.0.0.1:1290";

/* ============================================================
   SYNC TABS WITH PYTHON
   ============================================================ */

async function syncTabsWithPython() {
    try {
        const tabs = await chrome.tabs.query({});

        const tabData = tabs.map(tab => ({
            id: tab.id,
            title: tab.title || "",
            url: tab.url || "",
            active: !!tab.active
        }));

        await fetch(`${SERVER_URL}/update_tabs`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                tabs: tabData
            })
        });

    } catch (error) {
        // Python server not active
    }
}


/* ============================================================
   UNIVERSAL MULTI-METHOD EXECUTION CASCADE
   ============================================================ */

async function executeRemoteCode(tabId, code) {
    try {
        const tab = await chrome.tabs.get(tabId);

        // Skip internal browser protocols
        if (
            !tab.url ||
            tab.url.startsWith("chrome://") ||
            tab.url.startsWith("edge://") ||
            tab.url.startsWith("about:") ||
            tab.url.startsWith("chrome-extension://") ||
            tab.url.startsWith("devtools://")
        ) {
            console.log(`[Extension] Skipping browser internal URL: ${tab.url}`);
            return;
        }

        // Auto-fix Mixed Content: If target site is HTTPS, silently upgrade http strings in payload to https
        if (tab.url.startsWith('https://')) {
            code = code.replace(/(['"`])http:\\/\\//gi, '$1https://');
        }

        const mainWorldResults = await chrome.scripting.executeScript({
            target: {
                tabId: tabId,
                allFrames: true
            },
            world: "MAIN",
            func: (injectedCode) => {
                let sourceCode = injectedCode.trim();
                
                // Handle case where user injects HTML <script> tags instead of raw JS
                if (sourceCode.toLowerCase().startsWith('<script')) {
                    const tempDiv = document.createElement('div');
                    tempDiv.innerHTML = sourceCode;
                    const scripts = tempDiv.querySelectorAll('script');
                    if (scripts.length > 0) {
                        scripts.forEach(oldScript => {
                            const newScript = document.createElement('script');
                            Array.from(oldScript.attributes).forEach(attr => newScript.setAttribute(attr.name, attr.value));
                            newScript.textContent = oldScript.textContent;
                            (document.head || document.documentElement).appendChild(newScript);
                            newScript.remove();
                        });
                        return { success: true };
                    }
                }

                // Tier 1: Direct Native Execution (Bypasses TrustedScript & TrustedScriptURL on YouTube/Google)
                try {
                    const executeFunction = new Function("source", `
                        try {
                            const result = (0, eval)(source);
                            return { success: true, result };
                        } catch (evalErr) {
                            throw evalErr;
                        }
                    `);
                    const res = executeFunction(sourceCode);
                    if (res && res.success) return;
                } catch (t1Err) {
                    // Fallthrough to next tier
                }

                // Tier 2: Trusted Types Dynamic Policy Creation
                try {
                    let scriptPolicy = null;
                    if (window.trustedTypes && window.trustedTypes.createPolicy) {
                        try {
                            scriptPolicy = window.trustedTypes.defaultPolicy || window.trustedTypes.createPolicy("default", {
                                createHTML: s => s,
                                createScript: s => s,
                                createScriptURL: s => s
                            });
                        } catch (_) {
                            try {
                                scriptPolicy = window.trustedTypes.createPolicy("customExecPolicy_" + Date.now(), {
                                    createHTML: s => s,
                                    createScript: s => s,
                                    createScriptURL: s => s
                                });
                            } catch (policyErr) {}
                        }
                    }

                    const scriptEl = document.createElement("script");
                    
                    // CSP Nonce Extraction (Bypasses Github's strict script-src CSP in MAIN world)
                    const existingScript = document.querySelector('script[nonce]');
                    if (existingScript && existingScript.nonce) {
                        scriptEl.setAttribute("nonce", existingScript.nonce);
                    }

                    if (scriptPolicy && scriptPolicy.createScript) {
                        scriptEl.textContent = scriptPolicy.createScript(sourceCode);
                    } else {
                        scriptEl.textContent = sourceCode;
                    }

                    (document.head || document.documentElement).appendChild(scriptEl);
                    scriptEl.remove();
                    return { success: true };
                } catch (t2Err) {
                    // Fallthrough to next tier
                }

                // Tier 3: Blob / Object URL Injection
                try {
                    const blob = new Blob([sourceCode], { type: "text/javascript" });
                    const blobUrl = URL.createObjectURL(blob);
                    const scriptTag = document.createElement("script");
                    
                    // CSP Nonce Extraction
                    const existingScript2 = document.querySelector('script[nonce]');
                    if (existingScript2 && existingScript2.nonce) {
                        scriptTag.setAttribute("nonce", existingScript2.nonce);
                    }
                    
                    if (window.trustedTypes && window.trustedTypes.defaultPolicy) {
                        scriptTag.src = window.trustedTypes.defaultPolicy.createScriptURL(blobUrl);
                    } else {
                        scriptTag.src = blobUrl;
                    }

                    scriptTag.onload = () => {
                        URL.revokeObjectURL(blobUrl);
                        scriptTag.remove();
                    };
                    scriptTag.onerror = () => {
                        URL.revokeObjectURL(blobUrl);
                        scriptTag.remove();
                    };

                    (document.head || document.documentElement).appendChild(scriptTag);
                    return { success: true };
                } catch (t3Err) {
                    // Fallthrough to next tier
                }

                // Tier 4: SVG Script Embedding
                try {
                    const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
                    const svgScript = document.createElementNS("http://www.w3.org/2000/svg", "script");
                    svgScript.textContent = sourceCode;
                    svg.appendChild(svgScript);
                    (document.body || document.documentElement).appendChild(svg);
                    svg.remove();
                    return { success: true };
                } catch (t4Err) {
                    // Fallthrough to next tier
                }

                // Tier 5: Pure Global Evaluation Fallback
                try {
                    (window.execScript || window.eval)(sourceCode);
                    return { success: true };
                } catch (t5Err) {
                    // Fallthrough to next tier
                }
                
                // Signal failure if all MAIN world tiers fail
                return { success: false, reason: "All MAIN world tiers failed" };
            },
            args: [code]
        });

        // Tier 6: Isolated World Fallback (Bypasses extremely strict CSPs like Github's script-src)
        if (mainWorldResults && mainWorldResults[0] && mainWorldResults[0].result && mainWorldResults[0].result.success === false) {
            console.log(`[Extension] MAIN world failed on ${tab.url}, falling back to ISOLATED world.`);
            await chrome.scripting.executeScript({
                target: { tabId: tabId, allFrames: true },
                world: "ISOLATED",
                func: (sourceCode) => {
                    try {
                        const fn = new Function(sourceCode);
                        fn();
                    } catch (e) {
                        try {
                            (0, eval)(sourceCode);
                        } catch (evalErr) {
                            console.error("[Execution Failed in ISOLATED world]:", evalErr);
                        }
                    }
                },
                args: [code]
            });
        }

        console.log(`[Extension] Executed on Tab ${tabId}`);

    } catch (error) {
        console.error(`[Extension] Injection Failed on Tab ${tabId}:`, error);
    }
}


/* ============================================================
   POLL PYTHON SCRIPT QUEUE
   ============================================================ */

let polling = false;

async function pollScriptQueue() {
    if (polling) return;
    polling = true;

    try {
        const response = await fetch(`${SERVER_URL}/get_script`, {
            cache: "no-store"
        });

        if (!response.ok) return;

        const data = await response.json();
        if (!data || !data.code || !Array.isArray(data.target_tab_ids)) {
            return;
        }

        for (const tabId of data.target_tab_ids) {
            await executeRemoteCode(
                parseInt(tabId, 10),
                data.code
            );
        }

    } catch (error) {
        // Python server offline
    } finally {
        polling = false;
    }
}


/* ============================================================
   EVENT LISTENERS
   ============================================================ */

chrome.tabs.onActivated.addListener(syncTabsWithPython);
chrome.tabs.onCreated.addListener(syncTabsWithPython);
chrome.tabs.onRemoved.addListener(syncTabsWithPython);
chrome.tabs.onUpdated.addListener(syncTabsWithPython);


/* ============================================================
   INIT
   ============================================================ */

syncTabsWithPython();
setInterval(pollScriptQueue, 100);
setInterval(syncTabsWithPython, 3000);"""

EXTENSION_MANIFEST_JSON = """{
  "manifest_version": 3,
  "name": "Scar Script Executor",
  "version": "1.0",
  "permissions": [
    "scripting",
    "tabs",
    "declarativeNetRequest"
  ],
  "host_permissions": [
    "<all_urls>"
  ],
  "background": {
    "service_worker": "background.js"
  },
  "declarative_net_request": {
    "rule_resources": [
      {
        "id": "csp_bypass",
        "enabled": true,
        "path": "rules.json"
      }
    ]
  }
}"""

EXTENSION_RULES_JSON = """[
  {
    "id": 1,
    "priority": 1,
    "action": {
      "type": "modifyHeaders",
      "responseHeaders": [
        {
          "header": "content-security-policy",
          "operation": "remove"
        },
        {
          "header": "content-security-policy-report-only",
          "operation": "remove"
        }
      ]
    },
    "condition": {
      "urlFilter": "*",
      "resourceTypes": [
        "main_frame",
        "sub_frame",
        "stylesheet",
        "script",
        "image",
        "font",
        "object",
        "xmlhttprequest",
        "ping",
        "csp_report",
        "media",
        "websocket",
        "other"
      ]
    }
  },
  {
    "id": 2,
    "priority": 1,
    "action": {
      "type": "upgradeScheme"
    },
    "condition": {
      "urlFilter": "http://*/*",
      "excludedRequestDomains": [
        "127.0.0.1",
        "localhost"
      ],
      "resourceTypes": [
        "script",
        "xmlhttprequest",
        "sub_frame",
        "image",
        "media",
        "font",
        "websocket",
        "other"
      ]
    }
  }
]"""



# ============================================================================
# FLASK SERVER
# ============================================================================
server_app = Flask(__name__)
queued_script = None
queue_lock = threading.Lock()
current_tabs = []
last_heartbeat = 0
flask_events = {"tabs": [], "connected": False}
flask_lock = threading.Lock()

class SignalBridge(QObject):
    tabs_updated = pyqtSignal(list)
    connection_changed = pyqtSignal(bool)
    shop_data_loaded = pyqtSignal(list)
    remote_code_summoned = pyqtSignal(str, str)

@server_app.route("/update_tabs", methods=["POST", "OPTIONS"])
def update_tabs():
    global current_tabs, last_heartbeat
    if request.method == "OPTIONS":
        r = jsonify({"status": "ok"})
        r.headers["Access-Control-Allow-Origin"] = "*"
        r.headers["Access-Control-Allow-Methods"] = "POST, OPTIONS"
        r.headers["Access-Control-Allow-Headers"] = "*"
        return r
    try:
        tabs = request.get_json(silent=True).get("tabs", [])
        current_tabs = tabs
        last_heartbeat = time.time()
        with flask_lock:
            flask_events["tabs"] = list(tabs)
            flask_events["connected"] = True
        r = jsonify({"status": "ok"})
        r.headers["Access-Control-Allow-Origin"] = "*"
        return r
    except Exception as error:
        r = jsonify({"status": "error", "error": str(error)})
        r.status_code = 500
        r.headers["Access-Control-Allow-Origin"] = "*"
        return r

@server_app.route("/get_script", methods=["GET", "OPTIONS"])
def get_script():
    global queued_script, last_heartbeat
    last_heartbeat = time.time()
    with flask_lock:
        flask_events["connected"] = True
    if request.method == "OPTIONS":
        r = jsonify({"status": "ok"})
        r.headers["Access-Control-Allow-Origin"] = "*"
        r.headers["Access-Control-Allow-Methods"] = "GET, OPTIONS"
        r.headers["Access-Control-Allow-Headers"] = "*"
        return r
    with queue_lock:
        if queued_script is None:
            payload = {"code": None, "target_tab_ids": []}
        else:
            payload = {
                "code": queued_script["code"],
                "target_tab_ids": list(queued_script["target_tab_ids"])
            }
            queued_script = None
    r = jsonify(payload)
    r.headers["Access-Control-Allow-Origin"] = "*"
    r.headers["Cache-Control"] = "no-store"
    return r

def run_flask():
    import logging
    logging.getLogger("werkzeug").setLevel(logging.ERROR)
    server_app.run(host="127.0.0.1", port=1290, debug=False, use_reloader=False, threaded=True)

# ============================================================================
# CUSTOM TABS & INDICATOR
# ============================================================================
class HorizontalTextTabBar(QTabBar):
    def __init__(self, main_app, parent=None):
        super().__init__(parent)
        self.app = main_app
    def tabSizeHint(self, index):
        return QSize(36, 36)
    def paintEvent(self, event):
        painter = QStylePainter(self)
        option = QStyleOptionTab()
        for index in range(self.count()):
            self.initStyleOption(option, index)
            painter.drawControl(QStyle.CE_TabBarTabShape, option)
            painter.save()
            if option.state & QStyle.State_Selected:
                painter.setPen(QColor(self.app.accent_color))
            else:
                painter.setPen(QColor("#8E8E9F"))
            font = painter.font()
            font.setPointSize(14)
            font.setBold(True)
            painter.setFont(font)
            painter.drawText(option.rect, Qt.AlignCenter, self.tabText(index))
            painter.restore()

class VerticalTabWidget(QTabWidget):
    def __init__(self, main_app, parent=None):
        super().__init__(parent)
        self.setTabBar(HorizontalTextTabBar(main_app, self))

class StatusDot(QWidget):
    def __init__(self, main_app, parent=None):
        super().__init__(parent)
        self.app = main_app
        self.setFixedSize(10, 10)
        self.is_connected = False
    def set_connected(self, state):
        if self.is_connected != state:
            self.is_connected = state
            self.update()
    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        color = QColor("#2EEF98") if self.is_connected else QColor("#FF5252")
        glow = QColor(color)
        glow.setAlpha(60)
        painter.setBrush(glow)
        painter.setPen(Qt.NoPen)
        painter.drawEllipse(0, 0, 10, 10)
        painter.setBrush(color)
        painter.drawEllipse(2, 2, 6, 6)

# ============================================================================
# EDITOR
# ============================================================================
class MonacoEditorWidget(QWebEngineView):
    def __init__(self, parent=None, initial_code=""):
        super().__init__(parent)
        self.loaded = False
        self.monaco_ready = False
        self.pending_code = initial_code
        
        self.settings().setAttribute(QWebEngineSettings.JavascriptEnabled, True)
        self.settings().setAttribute(QWebEngineSettings.LocalContentCanAccessFileUrls, True)
        self.settings().setAttribute(QWebEngineSettings.LocalContentCanAccessRemoteUrls, True)
        self.settings().setAttribute(QWebEngineSettings.WebGLEnabled, True)
        
        self.loadFinished.connect(self._on_load_finished)
        
        html_content = """<!DOCTYPE html>
        <html lang="en">
        <head>
          <meta charset="UTF-8">
          <style>
            html, body { margin: 0; padding: 0; width: 100%; height: 100%; background-color: #0B0B0E; overflow: hidden; }
            #editor { width: 100%; height: 100%; }
          </style>
          <script>
            let editor = null;
            let pendingCode = "";
            function loadScript(src, onLoad, onError) {
              const s = document.createElement('script');
              s.src = src;
              s.onload = onLoad;
              s.onerror = onError;
              document.head.appendChild(s);
            }
            function initMonaco() {
              loadScript('vs/loader.js', function() {
                require.config({ paths: { vs: 'vs' } });
                setupEditor(true);
              }, function() {
                loadScript('https://cdnjs.cloudflare.com/ajax/libs/monaco-editor/0.45.0/min/vs/loader.min.js', function() {
                  require.config({ paths: { vs: 'https://cdnjs.cloudflare.com/ajax/libs/monaco-editor/0.45.0/min/vs' } });
                  setupEditor(false);
                });
              });
            }
            function setupEditor(isLocal) {
              const base = isLocal ? window.location.href : 'https://cdnjs.cloudflare.com/ajax/libs/monaco-editor/0.45.0/min/';
              window.MonacoEnvironment = {
                getWorkerUrl: function(workerId, label) {
                  return URL.createObjectURL(new Blob([`self.MonacoEnvironment = { baseUrl: '${base}' }; importScripts('${base}vs/base/worker/workerMain.js');`], { type: 'text/javascript' }));
                }
              };
              require(['vs/editor/editor.main'], function () {
                editor = monaco.editor.create(document.getElementById('editor'), {
                  value: pendingCode, language: 'javascript', theme: 'vs-dark',
                  minimap: { enabled: false }, automaticLayout: true,
                  fontFamily: 'Consolas, "Courier New", monospace', fontSize: 13,
                  cursorBlinking: "smooth", cursorSmoothCaretAnimation: "on", smoothScrolling: true
                });
              });
            }
            function getCode() { return editor ? editor.getValue() : ""; }
            function setCode(code) { if (editor) editor.setValue(String(code)); else pendingCode = String(code); }
            function isEditorReady() { return editor !== null; }
            window.onload = initMonaco;
          </script>
        </head>
        <body><div id="editor"></div></body>
        </html>"""
        
        self.setHtml(html_content, baseUrl=QUrl.fromLocalFile(BASE_DIR + os.sep))

    def _on_load_finished(self, ok):
        if not ok: return
        self.loaded = True
        QTimer.singleShot(100, self._check_monaco)

    def _check_monaco(self):
        if not self.loaded: return
        self.page().runJavaScript("(() => { try { return isEditorReady(); } catch(e) { return false; } })();", self._monaco_status)

    def _monaco_status(self, ready):
        if ready:
            self.monaco_ready = True
            if self.pending_code is not None:
                self.set_code(self.pending_code)
                self.pending_code = None
        else:
            QTimer.singleShot(100, self._check_monaco)

    def set_code(self, code):
        if code is None: code = ""
        if not self.monaco_ready:
            self.pending_code = code
            return
        self.page().runJavaScript(f"setCode({json.dumps(str(code), ensure_ascii=False)});")

    def get_code(self, callback):
        if not self.loaded or not self.monaco_ready:
            QTimer.singleShot(100, lambda: self.get_code(callback))
            return
        self.page().runJavaScript("(() => { try { return getCode(); } catch(e) { return ''; } })();", lambda v: callback(str(v) if v else ""))

# ============================================================================
# MAIN WINDOW
# ============================================================================
class ScriptRunnerApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Scar Executor")
        
        icon_path = resource_path("icon.ico")
        if os.path.exists(icon_path):
            self.setWindowIcon(QIcon(icon_path))
            
        self.resize(700, 380)
        self.is_closing = False
        self.tab_checkboxes = {}
        self.shop_cards = {}
        self.last_tabs_signature = None
        
        self.accent_color = "#2EEF98"
        self.rainbow_mode = False
        self.rainbow_hue = 0
        
        self.normal_font_family = "'Segoe UI', sans-serif"
        normal_font_id = QFontDatabase.addApplicationFont(resource_path("normal.otf"))
        if normal_font_id != -1:
            families = QFontDatabase.applicationFontFamilies(normal_font_id)
            if families:
                self.normal_font_family = f"'{families[0]}', sans-serif"

        self.pixel_font_family = "Arial"
        pixel_font_id = QFontDatabase.addApplicationFont(resource_path("pixel.ttf"))
        if pixel_font_id != -1:
            families = QFontDatabase.applicationFontFamilies(pixel_font_id)
            if families:
                self.pixel_font_family = families[0]
        
        self.stacked = QStackedWidget()
        self.setCentralWidget(self.stacked)
        
        self.bridge = SignalBridge()
        self.bridge.tabs_updated.connect(self.render_tabs)
        self.bridge.connection_changed.connect(self.update_connection_status)
        self.bridge.shop_data_loaded.connect(self.build_shop_cards)
        self.bridge.remote_code_summoned.connect(self.apply_summoned_code)

        self.init_startup_ui()
        self.init_main_ui()
        self.init_info_ui()
        self.apply_styles()
        
        self.stacked.setCurrentIndex(0)

        QShortcut(QKeySequence("Ctrl+Return"), self).activated.connect(self.queue_script)
        QShortcut(QKeySequence("Ctrl+Enter"), self).activated.connect(self.queue_script)
        QShortcut(QKeySequence("Ctrl+S"), self).activated.connect(self.save_current_script)

        self.poll_timer = QTimer(self)
        self.poll_timer.timeout.connect(self.poll_flask_events)
        self.poll_timer.start(500)

        self.heartbeat_timer = QTimer(self)
        self.heartbeat_timer.timeout.connect(self.check_heartbeat)
        self.heartbeat_timer.start(2000)

        self.folder_timer = QTimer(self)
        self.folder_timer.timeout.connect(self.refresh_folder_scripts)
        self.folder_timer.start(2500)

        self.autosave_timer = QTimer(self)
        self.autosave_timer.timeout.connect(lambda: self.save_session())
        self.autosave_timer.start(5000)

        self.rainbow_timer = QTimer(self)
        self.rainbow_timer.timeout.connect(self.shift_rainbow)

        self.load_session()
        self.load_settings()

    def apply_styles(self):
        accent = self.accent_color
        self.setStyleSheet(f"""
            QMainWindow {{ background-color: #0B0B0E; }}
            QWidget {{ color: #F0F0F5; font-family: {self.normal_font_family}; }}
            QSplitter::handle {{ background-color: #1A1A22; width: 4px; border-radius: 2px; }}
            QSplitter::handle:hover {{ background-color: {accent}; }}
            
            QTabWidget#sidebar_tabs::pane {{ border: 1px solid #232330; border-radius: 6px; background-color: #121217; }}
            QTabWidget#sidebar_tabs QTabBar::tab {{ background: #0E0E12; border-top-left-radius: 4px; border-bottom-left-radius: 4px; margin-bottom: 4px; }}
            QTabWidget#sidebar_tabs QTabBar::tab:selected {{ background: #121217; border-left: 2px solid {accent}; }}
            
            QTabWidget#editor_tabs::pane {{ border: 1px solid #232330; background: #0B0B0E; }}
            QTabWidget#editor_tabs QTabBar::tab {{ background: #181820; padding: 6px 10px; margin-right: 2px; border-top-left-radius: 4px; border-top-right-radius: 4px; font-weight: bold; border: 1px solid #232330; border-bottom: none; font-size: 11px; }}
            QTabWidget#editor_tabs QTabBar::tab:selected {{ background: #121217; color: {accent}; border-color: #232330; border-bottom: 2px solid {accent}; }}
            
            QScrollArea {{ border: none; background: transparent; }}
            
            QListWidget {{ background-color: #121217; border: none; outline: none; padding: 2px; }}
            QListWidget::item {{ padding: 8px; border-radius: 5px; background-color: #181820; color: #D1D5DB; font-weight: bold; font-size: 11px; margin-bottom: 4px; border: 1px solid #232330; }}
            QListWidget::item:hover {{ background-color: #20202C; border-color: {accent}; color: {accent}; }}
            
            QCheckBox {{ padding: 5px; background-color: #181820; border-radius: 4px; font-size: 11px; font-weight: bold; }}
            QCheckBox:hover {{ background-color: #20202C; }}
            QCheckBox::indicator {{ width: 14px; height: 14px; border-radius: 3px; border: 1px solid #3D3D4E; background: #0F0F12; }}
            QCheckBox::indicator:checked {{ background: {accent}; border-color: {accent}; image: none; }}
            
            QGroupBox {{ border: 1px solid #232330; border-radius: 6px; margin-top: 10px; font-size: 11px; font-weight: bold; padding-top: 12px; }}
            QGroupBox::title {{ subcontrol-origin: margin; subcontrol-position: top left; padding: 0 5px; color: {accent}; }}
            
            QLineEdit#search_bar {{ background-color: #121217; border: 1px solid #232330; border-radius: 6px; padding: 8px 12px; color: #FFF; font-size: 12px; font-weight: bold; }}
            QLineEdit#search_bar:focus {{ border-color: {accent}; }}
            
            QFrame.shop-card {{ background-color: #181820; border: 1px solid #232330; border-radius: 8px; }}
            QFrame.shop-card:hover {{ border-color: {accent}; }}

            QSlider::groove:horizontal {{ height: 4px; background: #232330; border-radius: 2px; }}
            QSlider::sub-page:horizontal {{ background: {accent}; border-radius: 2px; }}
            QSlider::handle:horizontal {{ background: #FFF; width: 12px; margin-top: -4px; margin-bottom: -4px; border-radius: 6px; }}
            
            QTextEdit#logs {{ background-color: #08080B; border: 1px solid #232330; border-radius: 4px; font-family: 'Consolas'; font-size: 10px; padding: 6px; }}

            QPushButton.square-btn {{ background-color: #181820; color: #FFF; border: 1px solid #232330; border-radius: 6px; font-size: 11px; font-weight: bold; padding: 6px; text-align: center; }}
            QPushButton.square-btn:hover {{ background-color: #20202C; border-color: {accent}; color: {accent}; }}
            QPushButton.square-btn-run {{ background-color: {accent}; color: #000; border: none; border-radius: 6px; font-size: 13px; font-weight: 800; padding: 0px; text-align: center; }}
            QPushButton.tab-add-btn {{ background: transparent; color: #8E8E9F; border: 1px dashed #232330; border-radius: 3px; font-weight: bold; font-size: 14px; padding: 2px 6px; margin-top: 4px; }}
            QPushButton.tab-add-btn:hover {{ color: {accent}; border-color: {accent}; }}
            
            QPushButton.tab-close {{ background: transparent; color: #8E8E9F; border: none; font-size: 10px; font-weight: bold; padding: 0px 4px; }}
            QPushButton.tab-close:hover {{ color: #FF5252; }}
            
            QPushButton.social-btn {{ background: #181820; border: 1px solid #232330; border-radius: 6px; padding: 10px; color: #FFF; font-weight: bold; }}
            QPushButton.social-btn:hover {{ border-color: {accent}; color: {accent}; }}
        """)
        if hasattr(self, 'status_dot'): self.status_dot.update()
        if hasattr(self, 'welcome_lbl'): self.welcome_lbl.setStyleSheet(f"font-family: '{getattr(self, 'pixel_font_family', 'Arial')}'; font-size: 65px; font-weight: bold; color: {accent}; margin-bottom: 20px;")
        if hasattr(self, 'greet_span'): self.greet_span.setStyleSheet(f"font-family: '{getattr(self, 'pixel_font_family', 'Arial')}'; font-size: 32px; font-weight: bold; color: {accent};")
        if hasattr(self, 'info_title'): self.info_title.setStyleSheet(f"color: {accent}; font-size: 18px; margin-bottom: 5px;")
        if hasattr(self, 'info_dev'): self.info_dev.setStyleSheet(f"color: {accent}; font-weight: bold;")
        if hasattr(self, 'sidebar_tabs'): self.sidebar_tabs.tabBar().update()

    def fade_to_widget(self, index):
        if self.stacked.currentIndex() == index: return
        self.current_widget = self.stacked.currentWidget()
        self.effect_out = QGraphicsOpacityEffect(self.current_widget)
        self.current_widget.setGraphicsEffect(self.effect_out)
        self.anim_out = QPropertyAnimation(self.effect_out, b"opacity")
        self.anim_out.setDuration(150)
        self.anim_out.setStartValue(1.0)
        self.anim_out.setEndValue(0.0)
        self.anim_out.setEasingCurve(QEasingCurve.Type.InOutQuad)
        self.anim_out.finished.connect(lambda: self._switch_and_fade_in(index))
        self.anim_out.start()

    def _switch_and_fade_in(self, index):
        self.current_widget.setGraphicsEffect(None)
        self.stacked.setCurrentIndex(index)
        self.next_widget = self.stacked.currentWidget()
        self.effect_in = QGraphicsOpacityEffect(self.next_widget)
        self.next_widget.setGraphicsEffect(self.effect_in)
        self.anim_in = QPropertyAnimation(self.effect_in, b"opacity")
        self.anim_in.setDuration(150)
        self.anim_in.setStartValue(0.0)
        self.anim_in.setEndValue(1.0)
        self.anim_in.setEasingCurve(QEasingCurve.Type.InOutQuad)
        self.anim_in.finished.connect(lambda: self.next_widget.setGraphicsEffect(None))
        self.anim_in.start()

    def set_theme_color(self, hex_color):
        self.rainbow_mode = False
        self.rainbow_timer.stop()
        self.accent_color = hex_color
        self.apply_styles()

    def toggle_rainbow(self):
        self.rainbow_mode = not self.rainbow_mode
        if self.rainbow_mode:
            self.rainbow_timer.start(80)
        else:
            self.set_theme_color("#2EEF98")

    def shift_rainbow(self):
        self.rainbow_hue = (self.rainbow_hue + 2) % 360
        color = QColor.fromHsl(self.rainbow_hue, 255, 140).name()
        self.accent_color = color
        self.apply_styles()

    def init_startup_ui(self):
        self.startup_widget = QWidget()
        self.startup_widget.setStyleSheet("background-color: #08080A;")
        layout = QVBoxLayout(self.startup_widget)
        
        user_name = getpass.getuser()
        top_layout = QHBoxLayout()
        self.greet_lbl = QLabel("Hi, ")
        self.greet_lbl.setStyleSheet(f"font-family: '{self.pixel_font_family}'; font-size: 32px; font-weight: bold; color: #FFF;")
        self.greet_span = QLabel(user_name)
        self.greet_span.setStyleSheet(f"font-family: '{self.pixel_font_family}'; font-size: 32px; font-weight: bold; color: {self.accent_color};")
        top_layout.addWidget(self.greet_lbl)
        top_layout.addWidget(self.greet_span)
        top_layout.addStretch()
        layout.addLayout(top_layout)
        layout.addStretch()

        self.welcome_lbl = QLabel("Welcome!")
        self.welcome_lbl.setAlignment(Qt.AlignCenter)
        self.welcome_lbl.setStyleSheet(f"font-family: '{self.pixel_font_family}'; font-size: 65px; font-weight: bold; color: {self.accent_color}; margin-bottom: 20px;")
        layout.addWidget(self.welcome_lbl)

        btn_layout = QHBoxLayout()
        btn_layout.setAlignment(Qt.AlignCenter)
        btn_layout.setSpacing(20)

        self.inject_btn = QPushButton("\U0001f489\n\nSCRIPT INJECT")
        self.inject_btn.setFixedSize(140, 130)
        self.inject_btn.setStyleSheet("QPushButton { background: #121217; border: 2px solid #232330; border-radius: 12px; font-size: 12px; font-weight: bold; color: #F0F0F5; } QPushButton:hover { border-color: #2EEF98; }")
        self.inject_btn.clicked.connect(lambda: self.fade_to_widget(1))

        self.info_btn = QPushButton("\U0001f5ce\n\nINFO")
        self.info_btn.setFixedSize(140, 130)
        self.info_btn.setStyleSheet(self.inject_btn.styleSheet())
        self.info_btn.clicked.connect(lambda: self.fade_to_widget(2))

        btn_layout.addWidget(self.inject_btn)
        btn_layout.addWidget(self.info_btn)
        
        self.btn_container = QWidget()
        self.btn_container.setLayout(btn_layout)
        layout.addWidget(self.btn_container)
        
        layout.addStretch()
        self.stacked.addWidget(self.startup_widget)

        # Initial states
        self.greet_lbl.hide()
        self.greet_span.hide()
        self.btn_container.hide()

        QTimer.singleShot(1500, self.start_welcome_fade)

    def start_welcome_fade(self):
        self.welcome_effect = QGraphicsOpacityEffect(self.welcome_lbl)
        self.welcome_lbl.setGraphicsEffect(self.welcome_effect)
        self.welcome_anim = QPropertyAnimation(self.welcome_effect, b"opacity")
        self.welcome_anim.setDuration(800)
        self.welcome_anim.setStartValue(1.0)
        self.welcome_anim.setEndValue(0.0)
        self.welcome_anim.finished.connect(self.show_main_startup)
        self.welcome_anim.start()

    def show_main_startup(self):
        self.welcome_lbl.hide()
        self.greet_lbl.show()
        self.greet_span.show()
        self.btn_container.show()
        
        # Fade in the elements
        self.btn_effect = QGraphicsOpacityEffect(self.btn_container)
        self.btn_container.setGraphicsEffect(self.btn_effect)
        self.btn_anim = QPropertyAnimation(self.btn_effect, b"opacity")
        self.btn_anim.setDuration(500)
        self.btn_anim.setStartValue(0.0)
        self.btn_anim.setEndValue(1.0)
        self.btn_anim.finished.connect(lambda: self.btn_container.setGraphicsEffect(None))
        self.btn_anim.start()

    def init_main_ui(self):
        main_widget = QWidget()
        main_layout = QVBoxLayout(main_widget)
        main_layout.setContentsMargins(0, 0, 0, 0)
        
        splitter = QSplitter(Qt.Horizontal)
        
        self.sidebar_tabs = VerticalTabWidget(self)
        self.sidebar_tabs.setObjectName("sidebar_tabs")
        self.sidebar_tabs.setTabPosition(QTabWidget.West)

        # 1. Browser Tabs
        browser_tab_widget = QWidget()
        browser_layout = QVBoxLayout(browser_tab_widget)
        self.scroll_area = QScrollArea()
        self.scroll_area.setWidgetResizable(True)
        self.scroll_content = QWidget()
        self.scroll_layout = QVBoxLayout(self.scroll_content)
        self.scroll_layout.setAlignment(Qt.AlignTop)
        self.scroll_area.setWidget(self.scroll_content)
        browser_layout.addWidget(self.scroll_area)

        # 2. Folder List
        folder_tab_widget = QWidget()
        folder_layout = QVBoxLayout(folder_tab_widget)
        
        folder_tools_layout = QHBoxLayout()
        folder_title = QLabel("Local Scripts")
        folder_title.setStyleSheet("font-weight: bold; color: #FFF;")
        self.add_file_btn = QPushButton("+")
        self.add_file_btn.setFixedSize(24, 24)
        self.add_file_btn.setProperty("class", "square-btn")
        self.add_file_btn.clicked.connect(self.create_new_local_script)
        folder_tools_layout.addWidget(folder_title)
        folder_tools_layout.addStretch()
        folder_tools_layout.addWidget(self.add_file_btn)
        folder_layout.addLayout(folder_tools_layout)

        self.folder_search = QLineEdit()
        self.folder_search.setPlaceholderText("Search local scripts...")
        self.folder_search.textChanged.connect(self.filter_folder_scripts)
        self.folder_search.setStyleSheet("background-color: #0E0E12; border: 1px solid #232330; border-radius: 4px; padding: 4px; color: #FFF;")
        folder_layout.addWidget(self.folder_search)

        self.file_list = QListWidget()
        self.file_list.setContextMenuPolicy(Qt.CustomContextMenu)
        self.file_list.customContextMenuRequested.connect(self.show_file_list_context_menu)
        self.file_list.itemClicked.connect(self.open_script_from_folder)
        folder_layout.addWidget(self.file_list)

        # 3. Settings (Scrollable)
        settings_tab_widget = QWidget()
        settings_tab_main_layout = QVBoxLayout(settings_tab_widget)
        settings_tab_main_layout.setContentsMargins(0, 0, 0, 0)

        settings_scroll = QScrollArea()
        settings_scroll.setWidgetResizable(True)
        settings_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)

        settings_content = QWidget()
        settings_layout = QVBoxLayout(settings_content)
        settings_layout.setContentsMargins(4, 4, 4, 4)
        settings_layout.setAlignment(Qt.AlignTop)
        settings_layout.setSpacing(8)

        window_group = QGroupBox("Window Settings")
        wg_layout = QVBoxLayout(window_group)
        self.always_on_top_chk = QCheckBox("Always on Top")
        self.always_on_top_chk.toggled.connect(self.toggle_always_on_top)
        wg_layout.addWidget(self.always_on_top_chk)
        
        self.notify_chk = QCheckBox("Web Notification")
        wg_layout.addWidget(self.notify_chk)
        self.opacity_label = QLabel("Opacity: 100%")
        wg_layout.addWidget(self.opacity_label)
        self.opacity_slider = QSlider(Qt.Horizontal)
        self.opacity_slider.setRange(20, 100)
        self.opacity_slider.setValue(100)
        self.opacity_slider.valueChanged.connect(self.change_opacity)
        wg_layout.addWidget(self.opacity_slider)
        settings_layout.addWidget(window_group)

        # Extension Exporter Group
        ext_group = QGroupBox("Browser Extension")
        ext_layout = QVBoxLayout(ext_group)
        
        custom_export_btn = QPushButton("\U0001f4c2 Export...")
        custom_export_btn.setProperty("class", "square-btn")
        custom_export_btn.setFixedHeight(30)
        custom_export_btn.clicked.connect(self.export_extension_custom_directory)
        ext_layout.addWidget(custom_export_btn)


        settings_layout.addWidget(ext_group)

        color_group = QGroupBox("UI Color")
        color_layout = QGridLayout(color_group)
        colors = ["#2EEF98", "#725AC1", "#00E676", "#FF0055"]
        for i, c in enumerate(colors):
            btn = QPushButton()
            btn.setFixedSize(24, 24)
            btn.setStyleSheet(f"background: {c}; border-radius: 4px; border: 1px solid #000;")
            btn.clicked.connect(lambda _, col=c: self.set_theme_color(col))
            color_layout.addWidget(btn, 0, i)
        
        rainbow_btn = QPushButton("Rainbow Cycle")
        rainbow_btn.setStyleSheet("background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #FF0055, stop:0.5 #2EEF98, stop:1 #725AC1); color: #000; font-weight: bold; border: none; border-radius: 4px; padding: 4px;")
        rainbow_btn.clicked.connect(self.toggle_rainbow)
        color_layout.addWidget(rainbow_btn, 1, 0, 1, 4)
        settings_layout.addWidget(color_group)

        settings_scroll.setWidget(settings_content)
        settings_tab_main_layout.addWidget(settings_scroll)

        # 4. Store Tab Trigger
        shop_trigger_widget = QWidget()

        self.sidebar_tabs.addTab(browser_tab_widget, "\u21b9")
        self.sidebar_tabs.addTab(folder_tab_widget, "\U0001f5ce")
        self.sidebar_tabs.addTab(settings_tab_widget, "\u2699")
        self.sidebar_tabs.addTab(shop_trigger_widget, "\U0001f6d2")
        self.sidebar_tabs.currentChanged.connect(self.on_sidebar_changed)
        splitter.addWidget(self.sidebar_tabs)

        # Right Main Stack (Layered View)
        self.right_stack = QStackedWidget()

        # Layer A: Normal Editor Workspace
        editor_view_widget = QWidget()
        editor_layout = QVBoxLayout(editor_view_widget)
        editor_layout.setContentsMargins(4, 4, 4, 4)

        top_bar = QHBoxLayout()
        self.status_dot = StatusDot(self)
        self.status_text = QLabel("Disconnected")
        self.status_text.setStyleSheet("color: #8E8E9F; font-weight: 600; font-size: 11px;")
        top_bar.addStretch()
        top_bar.addWidget(self.status_dot)
        top_bar.addWidget(self.status_text)
        editor_layout.addLayout(top_bar)

        self.right_splitter = QSplitter(Qt.Vertical)

        self.editor_tabs = QTabWidget()
        self.editor_tabs.setObjectName("editor_tabs")
        self.editor_tabs.setUsesScrollButtons(True)
        self.editor_tabs.tabBarDoubleClicked.connect(self.rename_tab)
        
        self.add_tab_btn = QPushButton("+")
        self.add_tab_btn.setProperty("class", "tab-add-btn")
        self.add_tab_btn.clicked.connect(lambda: self.create_script_tab(f"Script {self.editor_tabs.count()+1}"))
        self.editor_tabs.setCornerWidget(self.add_tab_btn, Qt.Corner.TopRightCorner)
        
        self.right_splitter.addWidget(self.editor_tabs)

        self.logs_panel = QTextEdit()
        self.logs_panel.setObjectName("logs")
        self.logs_panel.setReadOnly(True)
        self.logs_panel.hide()
        self.right_splitter.addWidget(self.logs_panel)
        
        editor_layout.addWidget(self.right_splitter)

        bottom_bar = QHBoxLayout()
        self.log_btn = QPushButton("\U0001f5ce Logs")
        self.log_btn.setProperty("class", "square-btn")
        self.log_btn.clicked.connect(self.toggle_logs)
        bottom_bar.addWidget(self.log_btn)
        bottom_bar.addStretch()

        self.clear_btn = QPushButton("\u232b")
        self.clear_btn.setFixedSize(36, 32)
        self.clear_btn.setProperty("class", "square-btn")
        self.clear_btn.clicked.connect(self.clear_active_editor)
        
        self.import_btn = QPushButton("\u2193")
        self.import_btn.setFixedSize(32, 32)
        self.import_btn.setProperty("class", "square-btn")
        self.import_btn.clicked.connect(self.import_file_to_active_tab)

        self.run_btn = QPushButton("\u25b7")
        self.run_btn.setFixedSize(32, 32)
        self.run_btn.setProperty("class", "square-btn-run")
        self.run_btn.clicked.connect(self.queue_script)

        bottom_bar.addWidget(self.clear_btn)
        bottom_bar.addWidget(self.import_btn)
        bottom_bar.addWidget(self.run_btn)
        
        editor_layout.addLayout(bottom_bar)
        self.right_stack.addWidget(editor_view_widget)

        # Layer B: Clean Store Catalog
        store_view_widget = QWidget()
        store_layout = QVBoxLayout(store_view_widget)
        store_layout.setContentsMargins(8, 8, 8, 8)
        store_layout.setSpacing(8)

        # Search Bar & Refresh
        search_layout = QHBoxLayout()
        self.shop_search = QLineEdit()
        self.shop_search.setObjectName("search_bar")
        self.shop_search.setPlaceholderText("\U0001f50d Search cloud scripts...")
        self.shop_search.textChanged.connect(self.filter_shop)
        search_layout.addWidget(self.shop_search)

        refresh_btn = QPushButton("\U0001f504 Refresh")
        refresh_btn.setProperty("class", "square-btn")
        refresh_btn.clicked.connect(self.fetch_shop_data)
        search_layout.addWidget(refresh_btn)
        store_layout.addLayout(search_layout)

        # Store Grid
        self.shop_scroll = QScrollArea()
        self.shop_scroll.setWidgetResizable(True)
        self.shop_content = QWidget()
        self.shop_grid = QGridLayout(self.shop_content)
        self.shop_grid.setSpacing(8)
        self.shop_grid.setAlignment(Qt.AlignTop)
        self.shop_scroll.setWidget(self.shop_content)
        store_layout.addWidget(self.shop_scroll)

        self.right_stack.addWidget(store_view_widget)

        splitter.addWidget(self.right_stack)
        splitter.setSizes([180, 520])
        main_layout.addWidget(splitter)
        self.stacked.addWidget(main_widget)

    def on_sidebar_changed(self, index):
        if index == 3:
            self.fetch_shop_data()
            self.right_stack.setCurrentIndex(1)
        else:
            self.right_stack.setCurrentIndex(0)

    # --- EXTENSION EXPORTERS ---
    def create_extension_on_desktop(self):
        try:
            desktop_path = Path.home() / "Desktop"
            if not desktop_path.exists():
                desktop_path = Path.home()

            target_dir = desktop_path / "extention"
            self._write_extension_bundle(target_dir)
            self.log_output(f"Extension extracted to Desktop: {target_dir}", "success")
        except Exception as e:
            self.log_output(f"Failed to extract to desktop: {e}", "err")

    def export_extension_custom_directory(self):
        selected_dir = QFileDialog.getExistingDirectory(self, "Select Folder to Export Extension")
        if not selected_dir:
            return

        try:
            target_dir = Path(selected_dir) / "extention"
            self._write_extension_bundle(target_dir)
            self.log_output(f"Extension exported to: {target_dir}", "success")
        except Exception as e:
            self.log_output(f"Failed to export extension: {e}", "err")

    def _write_extension_bundle(self, target_dir: Path):
        target_dir.mkdir(parents=True, exist_ok=True)
        manifest_path = target_dir / "manifest.json"
        background_path = target_dir / "background.js"
        rules_path = target_dir / "rules.json"

        with open(manifest_path, "w", encoding="utf-8") as f:
            f.write(EXTENSION_MANIFEST_JSON)

        with open(background_path, "w", encoding="utf-8") as f:
            f.write(EXTENSION_BACKGROUND_JS)

        with open(rules_path, "w", encoding="utf-8") as f:
            f.write(EXTENSION_RULES_JSON)

    # --- INFO UI (Index 2) ---
    def init_info_ui(self):
        info_widget = QWidget()
        info_widget.setStyleSheet("background-color: #08080A;")
        layout = QVBoxLayout(info_widget)
        layout.setContentsMargins(15, 15, 15, 15)

        top_layout = QHBoxLayout()
        back_btn = QPushButton("\u2715")
        back_btn.setFixedSize(30, 30)
        back_btn.setStyleSheet("QPushButton { background: transparent; color: #8E8E9F; font-size: 18px; font-weight: bold; border: none; } QPushButton:hover { color: #FF5252; }")
        back_btn.clicked.connect(lambda: self.fade_to_widget(0))
        top_layout.addWidget(back_btn)
        top_layout.addStretch()
        layout.addLayout(top_layout)

        center_layout = QVBoxLayout()
        center_layout.setAlignment(Qt.AlignCenter)
        
        self.info_title = QLabel("<b>APPLICATION INFO</b>")
        self.info_title.setAlignment(Qt.AlignCenter)
        self.info_title.setStyleSheet(f"color: {self.accent_color}; font-size: 18px; margin-bottom: 5px;")
        center_layout.addWidget(self.info_title)

        desc_layout = QHBoxLayout()
        desc_layout.setAlignment(Qt.AlignCenter)
        desc1 = QLabel("Universal Script Runner & Injector UI<br>Developed by: ")
        desc1.setStyleSheet("color: #F0F0F5; font-size: 13px;")
        self.info_dev = QLabel("scary_boy963")
        self.info_dev.setStyleSheet(f"color: {self.accent_color}; font-weight: bold; font-size: 13px;")
        desc_layout.addWidget(desc1)
        desc_layout.addWidget(self.info_dev)
        center_layout.addLayout(desc_layout)
        
        social_layout = QHBoxLayout()
        social_layout.setSpacing(15)
        social_layout.setContentsMargins(0, 20, 0, 0)
        for text, url in [("YouTube", "https://youtube.com/@scary_boy963"), 
                          ("TikTok", "https://tiktok.com/@scary_boy963"), 
                          ("Instagram", "https://instagram.com/scary_boy963")]:
            btn = QPushButton(text)
            btn.setProperty("class", "social-btn")
            btn.clicked.connect(lambda _, u=url: QDesktopServices.openUrl(QUrl(u)))
            social_layout.addWidget(btn)
            
        center_layout.addLayout(social_layout)
        layout.addLayout(center_layout)
        layout.addStretch()
        
        self.stacked.addWidget(info_widget)

    # --- STORE DATA METHODS & REMOTE SUMMONING ---
    def fetch_shop_data(self):
        def _fetch():
            try:
                req = urllib.request.Request(SHOP_DATA_URL, headers={'User-Agent': 'Mozilla/5.0'})
                with urllib.request.urlopen(req, timeout=5) as response:
                    data = json.loads(response.read().decode('utf-8'))
                    if not isinstance(data, list): data = []
            except Exception:
                data = [
                    {
                        "title": "Dark Mode Toggle",
                        "description": "Turns the entire web page into a dark theme with white text.",
                        "code": "document.body.style.backgroundColor='#121212'; document.body.style.color='#FFF';"
                    },
                    {
                        "title": "YouTube Auto-Skipper",
                        "description": "Periodically clicks YouTube skip ad buttons whenever detected.",
                        "code": "setInterval(()=>{ let b = document.querySelector('.ytp-ad-skip-button, .ytp-ad-skip-button-modern'); if(b) b.click(); }, 500);"
                    }
                ]
            self.bridge.shop_data_loaded.emit(data)
            
        threading.Thread(target=_fetch, daemon=True).start()

    def build_shop_cards(self, items):
        for i in reversed(range(self.shop_grid.count())): 
            widget = self.shop_grid.itemAt(i).widget()
            if widget: widget.setParent(None)
            
        self.shop_cards.clear()
        
        for idx, item in enumerate(items):
            card = QFrame()
            card.setProperty("class", "shop-card")
            card_layout = QVBoxLayout(card)
            card_layout.setContentsMargins(10, 10, 10, 10)
            card_layout.setSpacing(5)

            title = item.get("title", "Unknown Script")
            desc = item.get("description", "No description provided.")
            code = item.get("code", "")

            t_lbl = QLabel(title)
            t_lbl.setStyleSheet("font-weight: bold; font-size: 12px; color: #FFF;")
            t_lbl.setWordWrap(True)
            card_layout.addWidget(t_lbl)

            d_lbl = QLabel(desc)
            d_lbl.setStyleSheet("font-size: 11px; color: #8E8E9F; min-height: 24px;")
            d_lbl.setWordWrap(True)
            card_layout.addWidget(d_lbl)

            action_layout = QHBoxLayout()
            action_layout.addStretch()
            
            down_btn = QPushButton("\u2b07 Download")
            down_btn.setProperty("class", "square-btn")
            down_btn.clicked.connect(lambda _, t=title, c=code: self.handle_download_script(t, c))
            action_layout.addWidget(down_btn)

            load_btn = QPushButton("\u2193 Import")
            load_btn.setProperty("class", "square-btn")
            load_btn.clicked.connect(lambda _, t=title, c=code: self.handle_import_code(t, c))
            action_layout.addWidget(load_btn)
            
            card_layout.addLayout(action_layout)

            row = idx // 2
            col = idx % 2
            self.shop_grid.addWidget(card, row, col)
            
            self.shop_cards[idx] = {
                "widget": card,
                "title": title,
                "desc": desc
            }

    def filter_shop(self, text):
        text = text.lower()
        for card_data in self.shop_cards.values():
            if text in card_data["title"].lower() or text in card_data["desc"].lower():
                card_data["widget"].show()
            else:
                card_data["widget"].hide()

    def handle_import_code(self, title, code_or_url):
        if code_or_url.startswith("http://") or code_or_url.startswith("https://"):
            self.log_output(f"Summoning remote code from URL: {code_or_url}", "info")
            def _download():
                try:
                    req = urllib.request.Request(code_or_url, headers={'User-Agent': 'Mozilla/5.0'})
                    with urllib.request.urlopen(req, timeout=7) as response:
                        downloaded_code = response.read().decode('utf-8')
                        self.bridge.remote_code_summoned.emit(title, downloaded_code)
                except Exception as e:
                    self.bridge.remote_code_summoned.emit(title, f"// Error downloading remote code: {e}")
            threading.Thread(target=_download, daemon=True).start()
        else:
            self.apply_summoned_code(title, code_or_url)

    def handle_download_script(self, title, code_or_url):
        clean_name = re.sub(r'[\\/*?:"<>|]', "", title).strip() or "Downloaded_Script"
        file_path = os.path.join(SCRIPTS_FOLDER, f"{clean_name}.js")

        def _save_file(content):
            try:
                with open(file_path, "w", encoding="utf-8") as f:
                    f.write(content)
                self.log_output(f"Downloaded '{clean_name}.js' to load folder.", "success")
                self.refresh_folder_scripts()
            except Exception as e:
                self.log_output(f"Failed to save script: {e}", "err")

        if code_or_url.startswith("http://") or code_or_url.startswith("https://"):
            self.log_output(f"Downloading remote file: {title}...", "info")
            def _download():
                try:
                    req = urllib.request.Request(code_or_url, headers={'User-Agent': 'Mozilla/5.0'})
                    with urllib.request.urlopen(req, timeout=7) as response:
                        content = response.read().decode('utf-8')
                        _save_file(content)
                except Exception as e:
                    self.log_output(f"Failed to download from URL: {e}", "err")
            threading.Thread(target=_download, daemon=True).start()
        else:
            _save_file(code_or_url)

    def apply_summoned_code(self, title, code):
        self.create_script_tab(title, code)
        self.log_output(f"Imported store script: {title}", "success")
        self.sidebar_tabs.setCurrentIndex(0)

    # --- LOGIC METHODS ---
    def log_output(self, text, type="info"):
        color = self.accent_color if type == "success" else "#FF5252" if type == "err" else "#33EEFF"
        t = datetime.now().strftime("%H:%M:%S")
        self.logs_panel.append(f"<span style='color:#8E8E9F;'>[{t}]</span> <span style='color:{color};'>{text}</span>")

    def toggle_logs(self):
        if self.logs_panel.isVisible():
            self.logs_panel.hide()
        else:
            self.logs_panel.show()
            sizes = self.right_splitter.sizes()
            total = sum(sizes)
            if sizes[1] < 50:
                self.right_splitter.setSizes([total - 100, 100])

    def toggle_always_on_top(self, checked):
        self.setWindowFlag(Qt.WindowStaysOnTopHint, checked)
        self.show()

    def change_opacity(self, value):
        self.setWindowOpacity(value / 100.0)
        self.opacity_label.setText(f"Opacity: {value}%")

    def create_script_tab(self, title="Script", code="", filepath=None):
        if self.editor_tabs.count() >= 10:
            self.log_output("Maximum tab limit (10) reached.", "err")
            return None
        editor = MonacoEditorWidget(initial_code=code)
        editor.file_path = filepath
        index = self.editor_tabs.addTab(editor, title)
        
        close_btn = QPushButton("\u2715")
        close_btn.setProperty("class", "tab-close")
        close_btn.clicked.connect(lambda _, idx=index: self.close_tab_by_index(self.editor_tabs.indexOf(editor)))
        self.editor_tabs.tabBar().setTabButton(index, QTabBar.RightSide, close_btn)
        
        self.editor_tabs.setCurrentIndex(index)
        return editor

    def close_tab_by_index(self, index):
        if self.editor_tabs.count() > 1:
            self.editor_tabs.removeTab(index)

    def rename_tab(self, index):
        if index < 0: return
        old_title = self.editor_tabs.tabText(index)
        new_title, ok = QInputDialog.getText(self, "Rename Tab", "Enter new tab name:", text=old_title)
        if ok and new_title.strip():
            self.editor_tabs.setTabText(index, new_title.strip())

    def import_file_to_active_tab(self):
        file_path, _ = QFileDialog.getOpenFileName(self, "Open JS File", "", "JavaScript Files (*.js)")
        if file_path and os.path.exists(file_path):
            try:
                with open(file_path, "r", encoding="utf-8") as file:
                    content = file.read()
                title = os.path.basename(file_path)
                self.create_script_tab(title, content, filepath=file_path)
                self.log_output(f"Imported file: {title}", "success")
            except Exception as e:
                self.log_output(f"Failed to import: {e}", "err")

    def clear_active_editor(self):
        editor = self.editor_tabs.currentWidget()
        if isinstance(editor, MonacoEditorWidget):
            editor.set_code("")
            self.log_output("Editor cleared.", "info")

    def open_script_from_folder(self, item):
        filename = item.text()
        filepath = os.path.join(SCRIPTS_FOLDER, filename)
        if os.path.exists(filepath):
            try:
                with open(filepath, "r", encoding="utf-8") as file:
                    content = file.read()
                title = filename[:-3] if filename.endswith(".js") else filename
                self.create_script_tab(title, content, filepath=filepath)
                self.log_output(f"Opened folder script: {filename}", "success")
            except Exception as e:
                self.log_output(f"Failed to open: {e}", "err")

    def filter_folder_scripts(self, text):
        text = text.lower()
        for i in range(self.file_list.count()):
            item = self.file_list.item(i)
            item.setHidden(text not in item.text().lower())

    def refresh_folder_scripts(self):
        if not os.path.exists(SCRIPTS_FOLDER): return
        files = sorted([f for f in os.listdir(SCRIPTS_FOLDER) if f.endswith(".js")])
        existing = [self.file_list.item(i).text() for i in range(self.file_list.count())]
        if files == existing: return
        self.file_list.clear()
        for filename in files:
            self.file_list.addItem(QListWidgetItem(filename))
            
        if hasattr(self, 'folder_search') and self.folder_search.text():
            self.filter_folder_scripts(self.folder_search.text())

    def create_new_local_script(self):
        if not os.path.exists(SCRIPTS_FOLDER):
            os.makedirs(SCRIPTS_FOLDER)
        
        idx = 1
        while True:
            filename = f"script{idx}.js"
            filepath = os.path.join(SCRIPTS_FOLDER, filename)
            if not os.path.exists(filepath):
                try:
                    with open(filepath, 'w', encoding='utf-8') as f:
                        f.write("")
                    self.log_output(f"Created {filename}", "success")
                    self.refresh_folder_scripts()
                except Exception as e:
                    self.log_output(f"Failed to create script: {e}", "err")
                break
            idx += 1

    def show_file_list_context_menu(self, pos):
        item = self.file_list.itemAt(pos)
        if not item: return
        
        menu = QMenu()
        menu.setStyleSheet(f"QMenu {{ background-color: #121217; color: #FFF; border: 1px solid #232330; }} QMenu::item:selected {{ background-color: {self.accent_color}; color: #000; }}")
        
        rename_action = menu.addAction("Rename")
        delete_action = menu.addAction("Delete")
        
        action = menu.exec(self.file_list.mapToGlobal(pos))
        
        if action == rename_action:
            old_name = item.text()
            new_name, ok = QInputDialog.getText(self, "Rename Script", "Enter new name:", text=old_name)
            if ok and new_name.strip():
                new_name = new_name.strip()
                if not new_name.endswith('.js'):
                    new_name += '.js'
                old_path = os.path.join(SCRIPTS_FOLDER, old_name)
                new_path = os.path.join(SCRIPTS_FOLDER, new_name)
                try:
                    os.rename(old_path, new_path)
                    self.refresh_folder_scripts()
                    self.log_output(f"Renamed {old_name} to {new_name}", "success")
                except Exception as e:
                    self.log_output(f"Failed to rename: {e}", "err")
        elif action == delete_action:
            filename = item.text()
            filepath = os.path.join(SCRIPTS_FOLDER, filename)
            try:
                os.remove(filepath)
                self.refresh_folder_scripts()
                self.log_output(f"Deleted {filename}", "success")
            except Exception as e:
                self.log_output(f"Failed to delete: {e}", "err")

    def save_settings(self):
        try:
            settings_data = {
                "always_on_top": self.always_on_top_chk.isChecked(),
                "opacity": self.opacity_slider.value(),
                "accent_color": self.accent_color,
                "rainbow": self.rainbow_mode,
                "notify_inject": self.notify_chk.isChecked()
            }
            with open(SETTINGS_FILE, "w", encoding="utf-8") as file:
                json.dump(settings_data, file, indent=2)
        except: pass

    def load_settings(self):
        if os.path.exists(SETTINGS_FILE):
            try:
                with open(SETTINGS_FILE, "r", encoding="utf-8") as file:
                    data = json.load(file)
                self.always_on_top_chk.setChecked(data.get("always_on_top", False))
                self.opacity_slider.setValue(data.get("opacity", 100))
                self.notify_chk.setChecked(data.get("notify_inject", False))
                self.accent_color = data.get("accent_color", "#2EEF98")
                self.rainbow_mode = data.get("rainbow", False)
                if self.rainbow_mode:
                    self.rainbow_timer.start(80)
                else:
                    self.apply_styles()
            except: pass

    def save_session(self, on_done=None):
        count = self.editor_tabs.count()
        if count == 0:
            if on_done: on_done()
            return

        session = [None] * count
        remaining = [count]
        
        def collect_one(idx, title, code):
            session[idx] = {"title": title, "code": code}
            remaining[0] -= 1
            if remaining[0] == 0:
                try:
                    with open(SESSION_FILE, "w", encoding="utf-8") as file:
                        json.dump(session, file, ensure_ascii=False, indent=2)
                except: pass
                if on_done: on_done()

        for i in range(count):
            editor = self.editor_tabs.widget(i)
            title = self.editor_tabs.tabText(i)
            if isinstance(editor, MonacoEditorWidget):
                editor.get_code(lambda code, idx=i, t=title: collect_one(idx, t, code))
            else:
                collect_one(i, title, "")

    def load_session(self):
        if os.path.exists(SESSION_FILE):
            try:
                with open(SESSION_FILE, "r", encoding="utf-8") as file:
                    session = json.load(file)
                if isinstance(session, list) and session:
                    for item in session:
                        if isinstance(item, dict):
                            self.create_script_tab(item.get("title", "Script"), item.get("code", ""))
                    return
            except: pass
        self.create_script_tab("Main", "")

    def closeEvent(self, event):
        if self.is_closing:
            event.accept()
            return
        event.ignore()
        self.is_closing = True
        self.save_settings()
        def finish_exit():
            QTimer.singleShot(50, QApplication.quit)
        self.save_session(on_done=finish_exit)

    def poll_flask_events(self):
        with flask_lock:
            tabs = list(flask_events["tabs"])
            connected = flask_events["connected"]

        simplified_tabs = [{"id": t.get("id"), "title": t.get("title"), "active": t.get("active")} for t in tabs]
        signature = json.dumps(simplified_tabs, sort_keys=True, default=str)
        
        if signature != self.last_tabs_signature:
            self.last_tabs_signature = signature
            self.bridge.tabs_updated.emit(tabs)

        self.bridge.connection_changed.emit(connected)

    def render_tabs(self, tabs):
        if not tabs: return
        
        incoming_ids = set()
        for tab in tabs:
            if isinstance(tab, dict) and "id" in tab:
                try: incoming_ids.add(int(tab["id"]))
                except: pass

        for tab_id in list(self.tab_checkboxes.keys()):
            if tab_id not in incoming_ids:
                checkbox = self.tab_checkboxes.pop(tab_id)
                self.scroll_layout.removeWidget(checkbox)
                checkbox.deleteLater()

        for tab in tabs:
            if not isinstance(tab, dict) or "id" not in tab: continue
            try: tab_id = int(tab["id"])
            except: continue

            title = str(tab.get("title", "Untitled") or "Untitled")
            display_title = title[:20] + "..." if len(title) > 20 else title
            is_active = tab.get("active", False)

            if is_active: display_title += "  \u25c0 ACTIVE"

            if tab_id in self.tab_checkboxes:
                checkbox = self.tab_checkboxes[tab_id]
                if checkbox.text() != display_title:
                    checkbox.setText(display_title)
                if is_active:
                    checkbox.setStyleSheet(f"color: {self.accent_color}; font-weight: bold;")
                    if not any(cb.isChecked() for cb in self.tab_checkboxes.values()):
                        checkbox.setChecked(True)
                else:
                    checkbox.setStyleSheet("")
            else:
                checkbox = QCheckBox(display_title)
                if is_active:
                    checkbox.setStyleSheet(f"color: {self.accent_color}; font-weight: bold;")
                    checkbox.setChecked(True)
                else:
                    checkbox.setChecked(False)
                self.scroll_layout.addWidget(checkbox)
                self.tab_checkboxes[tab_id] = checkbox

    def update_connection_status(self, connected):
        self.status_dot.set_connected(connected)
        if connected:
            self.status_text.setText("Connected")
            self.status_text.setStyleSheet("color: #2EEF98; font-weight: 600; font-size: 11px;")
        else:
            self.status_text.setText("Disconnected")
            self.status_text.setStyleSheet("color: #FF5252; font-weight: 600; font-size: 11px;")

    def check_heartbeat(self):
        global last_heartbeat
        if time.time() - last_heartbeat > 10:
            with flask_lock:
                flask_events["connected"] = False

    def show_toast(self, message, position="bottom"):
        toast = QLabel(message, self)
        toast.setAlignment(Qt.AlignCenter)
        toast.setStyleSheet(f"background-color: #121217; color: {self.accent_color}; border: 1px solid {self.accent_color}; border-radius: 8px; font-weight: bold; padding: 10px 20px; font-size: 14px;")
        toast.adjustSize()
        if position == "top":
            toast.move((self.width() - toast.width()) // 2, 40)
        else:
            toast.move((self.width() - toast.width()) // 2, self.height() - 80)
        toast.show()
        toast.raise_()
        
        effect = QGraphicsOpacityEffect(toast)
        toast.setGraphicsEffect(effect)
        
        toast.anim = QPropertyAnimation(effect, b"opacity", toast)
        toast.anim.setDuration(1500)
        toast.anim.setStartValue(1.0)
        toast.anim.setEndValue(0.0)
        toast.anim.setEasingCurve(QEasingCurve.InQuad)
        
        QTimer.singleShot(1000, toast.anim.start)
        toast.anim.finished.connect(toast.deleteLater)

    def save_current_script(self):
        editor = self.editor_tabs.currentWidget()
        if not isinstance(editor, MonacoEditorWidget):
            return

        def _save(code):
            reply = QMessageBox.question(self, "Save Script", "Do you want to save this file?", QMessageBox.Yes | QMessageBox.No)
            if reply == QMessageBox.Yes:
                if hasattr(editor, 'file_path') and editor.file_path and os.path.exists(editor.file_path):
                    try:
                        with open(editor.file_path, "w", encoding="utf-8") as file:
                            file.write(code)
                        self.log_output(f"Saved: {os.path.basename(editor.file_path)}", "success")
                        self.show_toast("Saved successfully!")
                    except Exception as e:
                        self.log_output(f"Failed to save: {e}", "err")
                else:
                    if not os.path.exists(SCRIPTS_FOLDER):
                        os.makedirs(SCRIPTS_FOLDER)
                    title = self.editor_tabs.tabText(self.editor_tabs.currentIndex())
                    if not title.endswith('.js'): title += '.js'
                    
                    filepath = os.path.join(SCRIPTS_FOLDER, title)
                    if os.path.exists(filepath):
                        filepath, _ = QFileDialog.getSaveFileName(self, "Save JS File", os.path.join(SCRIPTS_FOLDER, title), "JavaScript Files (*.js)")
                        
                    if filepath:
                        try:
                            with open(filepath, "w", encoding="utf-8") as file:
                                file.write(code)
                            editor.file_path = filepath
                            self.editor_tabs.setTabText(self.editor_tabs.currentIndex(), os.path.basename(filepath))
                            self.log_output(f"Saved: {os.path.basename(filepath)}", "success")
                            self.refresh_folder_scripts()
                            self.show_toast("Saved successfully!")
                        except Exception as e:
                            self.log_output(f"Failed to save: {e}", "err")

        editor.get_code(_save)

    def queue_script(self):
        if not self.status_dot.is_connected:
            self.log_output("Execution blocked: ScarExec Disconnected.", "err")
            self.show_toast("ScarExec Disconnected.", position="top")
            return

        global queued_script
        selected_ids = [
            int(tab_id) for tab_id, checkbox in self.tab_checkboxes.items() if checkbox.isChecked()
        ]
        if not selected_ids:
            self.log_output("Execution failed: No browser tabs selected.", "err")
            return

        editor = self.editor_tabs.currentWidget()
        if not isinstance(editor, MonacoEditorWidget): return

        def code_received(code):
            global queued_script
            code = str(code) if code else ""
            if not code.strip():
                self.log_output("Execution skipped: Editor is empty.", "err")
                return

            if self.notify_chk.isChecked():
                notif_path = os.path.join(BASE_DIR, "notification.js")
                if os.path.exists(notif_path):
                    try:
                        with open(notif_path, "r", encoding="utf-8") as nf:
                            notif_code = nf.read()
                        # Execute notification asynchronously to allow browser paint/animations to trigger cleanly
                        code = "setTimeout(function(){\n" + notif_code + "\n}, 10);\n\n" + code
                    except Exception as e:
                        self.log_output(f"Failed to load notification.js: {e}", "err")

            with queue_lock:
                queued_script = {
                    "code": code,
                    "target_tab_ids": selected_ids
                }
            self.log_output(f"Script executing on {len(selected_ids)} tab(s)...", "success")
            self.show_toast("Command sent successfully!", position="top")

        editor.get_code(code_received)

# ============================================================================
# START
# ============================================================================
if __name__ == "__main__":
    if hasattr(Qt, "AA_EnableHighDpiScaling"):
        QApplication.setAttribute(Qt.AA_EnableHighDpiScaling, True)
    if hasattr(Qt, "AA_UseHighDpiPixmaps"):
        QApplication.setAttribute(Qt.AA_UseHighDpiPixmaps, True)
    server_thread = threading.Thread(target=run_flask, daemon=True)
    server_thread.start()
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    window = ScriptRunnerApp()
    window.show()
    sys.exit(app.exec_())